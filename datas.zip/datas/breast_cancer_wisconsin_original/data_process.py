import pandas as pd
from sklearn.preprocessing import MinMaxScaler

def preprocess_bcw_original(file_path, verbose=False):
    col_names = [
        "Sample_code_number",
        "Clump_Thickness",
        "Uniformity_Cell_Size",
        "Uniformity_Cell_Shape",
        "Marginal_Adhesion",
        "Single_Epithelial_Cell_Size",
        "Bare_Nuclei",
        "Bland_Chromatin",
        "Normal_Nucleoli",
        "Mitoses",
        "Class"
    ]

    df = pd.read_csv(file_path, header=None, names=col_names, na_values="?")

    if verbose:
        print("Raw data:", df.shape)

    df = df.dropna().reset_index(drop=True)

    if verbose:
        print("After drop NA:", df.shape)

    df = df.drop(columns=["Sample_code_number"])

    if verbose:
        print("After dropping Sample_code_number:", df.shape)

    df = df.rename(columns={"Class": "label"})
    label_series = df["label"].astype(int)

    unique_labels = sorted(label_series.unique())
    label_map = {val: idx for idx, val in enumerate(unique_labels)}
    df["label"] = label_series.map(label_map)

    if verbose:
        print("Label mapping:", label_map)

    feature_cols = [c for c in df.columns if c != "label"]

    scaler = MinMaxScaler()
    df_scaled = pd.DataFrame(
        scaler.fit_transform(df[feature_cols]),
        columns=feature_cols
    )

    df_scaled["label"] = df["label"].values

    if verbose:
        print("Final df shape:", df_scaled.shape)

    return df_scaled


if __name__ == "__main__":
    df_processed = preprocess_bcw_original("breast-cancer-wisconsin.data", verbose=True)
    print(df_processed.head())
    print("\nShape:", df_processed.shape)

    df_processed.to_csv('test.csv', index=False)
    clos = df_processed.columns
    with open('list.txt', 'w') as file:
        for j in clos:
            file.write(str(j) + '\n')