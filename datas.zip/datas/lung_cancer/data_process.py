import pandas as pd


data_path = "lung-cancer.data"
df_raw = pd.read_csv(data_path, header=None)

print("raw_data:", df_raw.shape)

df_raw = df_raw.rename(columns={0: "label"})

df_raw[4] = df_raw[4].replace("?", -1)
df_raw[38] = df_raw[38].replace("?", 4)

df_raw = df_raw.apply(pd.to_numeric)

label_col = df_raw["label"]
feature_df = df_raw.drop(columns=["label"])


df_features = pd.get_dummies(feature_df.astype(str))

df_features = df_features.astype(int)

# for column in df_raw.columns:
#     unique_values = df_raw[column].unique()
#     unique_count = df_raw[column].nunique()
#
#     print(f"\ncolumn '{column}':")
#     print(f"  different value number: {unique_count}")
#     print(f"  different value: {unique_values}")
#     print(f"  different value (sorted): {sorted(unique_values)}")

df_processed = pd.concat([df_features, label_col], axis=1)

print("processed_data:", df_processed.shape)
print(df_processed.head())

df_processed.to_csv('test.csv', index=False)
clos = df_processed.columns
with open('list.txt', 'w') as file:
    for j in clos:
        file.write(str(j)+'\n')