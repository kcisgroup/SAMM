import pandas as pd

data_path = "soybean-small.data"

df_raw = pd.read_csv(data_path, header=None)

print("raw data shape:", df_raw.shape)

df_raw = df_raw.rename(columns={df_raw.columns[-1]: "label"})

label_col = df_raw["label"]
feature_df = df_raw.drop(columns=["label"])

df_features = pd.get_dummies(feature_df.astype(str))

df_features = df_features.astype(int)


label_encoded, uniques = pd.factorize(label_col)

df_processed = pd.concat(
    [df_features.reset_index(drop=True),
     pd.Series(label_encoded, name="label")],
    axis=1
)

print("processed data shape:", df_processed.shape)
print(df_processed.head())

df_processed.to_csv('test.csv', index=False)
clos = df_processed.columns
with open('list.txt', 'w') as file:
    for j in clos:
        file.write(str(j)+'\n')

