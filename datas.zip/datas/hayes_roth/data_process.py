import pandas as pd

data_path = "hayes-roth.data"

df_raw = pd.read_csv(data_path, header=None)

columns = [
    "name", "hobby", "age", "educational level", "marital status", "class"
]

df_raw.columns = columns

print("raw data shape：", df_raw.shape)

df = df_raw.drop(columns=["name"])

df = df.rename(columns={"class": "label"})

label = df["label"]
features = df.drop(columns=["label"])

df_features = pd.get_dummies(features.astype(str))

df_features = df_features.astype(int)

df_processed = pd.concat([df_features.reset_index(drop=True), label.reset_index(drop=True)], axis=1)

print("processed data shape：", df_processed.shape)
print(df_processed.head())

df_processed.to_csv('test.csv', index=False)
clos = df_processed.columns
with open('list.txt', 'w') as file:
    for j in clos:
        file.write(str(j)+'\n')
