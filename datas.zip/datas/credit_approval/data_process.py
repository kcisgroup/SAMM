import pandas as pd
from sklearn.preprocessing import MinMaxScaler

def preprocess_credit_approval(file_path, verbose=False):
    col_names = [
        "A1", "A2", "A3", "A4", "A5", "A6", "A7", "A8",
        "A9", "A10", "A11", "A12", "A13", "A14", "A15", "A16"
    ]

    df = pd.read_csv(file_path, names=col_names, header=None, na_values="?")

    if verbose:
        print("Raw data:", df.shape)

    df = df.dropna().reset_index(drop=True)

    if verbose:
        print("After drop NA:", df.shape)

    df = df.rename(columns={"A16": "label"})

    categorical_cols = ["A1", "A4", "A5", "A6", "A7", "A9", "A10", "A12", "A13"]

    numeric_cols = ["A2", "A3", "A8", "A11", "A14", "A15"]

    df_onehot = pd.get_dummies(df[categorical_cols].astype(str), dtype=int).reset_index(drop=True)

    if verbose:
        print("One-hot shape:", df_onehot.shape)

    scaler = MinMaxScaler()
    df_numeric = pd.DataFrame(
        scaler.fit_transform(df[numeric_cols]),
        columns=numeric_cols
    ).reset_index(drop=True)

    if verbose:
        print("Numeric normalized shape:", df_numeric.shape)

    unique_labels = sorted(df["label"].unique())
    label_map = {val: i for i, val in enumerate(unique_labels)}
    df["label"] = df["label"].map(label_map)

    if verbose:
        print("Label mapping:", label_map)

    final_df = pd.concat([df_numeric, df_onehot], axis=1)
    final_df["label"] = df["label"].values

    if verbose:
        print("Final df shape:", final_df.shape)

    return final_df


if __name__ == "__main__":
    df_processed = preprocess_credit_approval("crx.data", verbose=True)
    print(df_processed.head())
    print("\nShape:", df_processed.shape)

    df_processed.to_csv('test.csv', index=False)
    clos = df_processed.columns
    with open('list.txt', 'w') as file:
        for j in clos:
            file.write(str(j) + '\n')
