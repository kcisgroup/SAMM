import pandas as pd
from sklearn.preprocessing import MinMaxScaler

def preprocess_balance_scale(file_path):
    col_names = ["class", "left_weight", "left_distance", "right_weight", "right_distance"]
    df = pd.read_csv(file_path, header=None, names=col_names)

    df = df.rename(columns={"class": "label"})

    label_map = {v: i for i, v in enumerate(df["label"].unique())}
    df["label"] = df["label"].map(label_map)

    labels = df["label"]
    features = df.drop(columns=["label"])

    scaler = MinMaxScaler()
    features_scaled = pd.DataFrame(scaler.fit_transform(features),
                                   columns=features.columns)

    features_scaled["label"] = labels.values

    return features_scaled, label_map


# 示例使用
if __name__ == "__main__":
    processed_df, label_map = preprocess_balance_scale("balance-scale.data")
    print(processed_df.head())
    print("\nLabel mapping:", label_map)
    print("\nShape:", processed_df.shape)

    processed_df.to_csv('test.csv', index=False)
    clos = processed_df.columns
    with open('list.txt', 'w') as file:
        for j in clos:
            file.write(str(j) + '\n')
