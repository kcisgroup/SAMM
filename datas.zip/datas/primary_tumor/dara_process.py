import pandas as pd


def preprocess_primary_tumor(file_path):
    col_names = [
        "class",
        "age",
        "sex",
        "histologic-type",
        "degree-of-diffe",
        "bone",
        "bone-marryow",
        "lung",
        "pleura",
        "peritoneum",
        "liver",
        "brain",
        "skin",
        "neck",
        "supraclavicular",
        "axillar",
        "mediastinum",
        "abdominal"
    ]

    df = pd.read_csv(file_path, header=None, names=col_names, na_values='?')

    df = df.dropna(axis=1)

    df_raw = df.rename(columns={"class": "label"})

    df_raw = df_raw.apply(pd.to_numeric)

    label_col = df_raw["label"]
    feature_df = df_raw.drop(columns=["label"])

    df_features = pd.get_dummies(feature_df.astype(str))

    df_features = df_features.astype(int)

    df_processed = pd.concat([df_features, label_col], axis=1)

    print("processed_data:", df_processed.shape)
    print(df_processed.head())

    df_processed.to_csv('test.csv', index=False)
    clos = df_processed.columns
    with open('list.txt', 'w') as file:
        for j in clos:
            file.write(str(j) + '\n')


if __name__ == "__main__":
    preprocess_primary_tumor("primary-tumor.data")

