import pandas as pd

data_path = "lymphography.data"

df_raw = pd.read_csv(data_path, header=None)

columns = [
    "class", "lymphatics", "block of affere", "bl. of lymph. c", "bl. of lymph. s", "by pass",
    "extravasates", "regeneration of", "early uptake in", "lym.nodes dimin", "lym.nodes enlar",
    "changes in lym", "defect in node", "changes in node", "changes in stru",
    "special forms", "dislocation of", "exclusion of no", "no. of nodes in"
]

df_raw.columns = columns

print("raw data shape：", df_raw.shape)

# df = df_raw.drop(columns=["name"])

df = df_raw.rename(columns={"class": "label"})

label = df["label"]
features = df.drop(columns=["label"])

df_features = pd.get_dummies(features.astype(str))

df_features = df_features.astype(int)

df_processed = pd.concat([df_features.reset_index(drop=True), label.reset_index(drop=True)], axis=1)

print("processed data shape：", df_processed.shape)
print(df_processed.head())

df_processed.to_csv('test.csv', index=False)
clos = df_processed.columns
with open('list.txt', 'w') as file:
    for j in clos:
        file.write(str(j)+'\n')
