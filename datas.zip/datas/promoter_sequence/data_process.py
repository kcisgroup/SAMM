import pandas as pd

def preprocess_promoter_gene_onehot(file_path):
    data = []

    mapping = {
        'a': [1, 0, 0, 0],
        'c': [0, 1, 0, 0],
        'g': [0, 0, 1, 0],
        't': [0, 0, 0, 1]
    }

    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            parts = line.split(',')

            label_raw = parts[0].strip()
            seq = parts[2].strip().lower()

            label = 0 if label_raw == '+' else 1

            seq_onehot = []
            for ch in seq:
                seq_onehot.extend(mapping[ch])

            data.append(seq_onehot + [label])

    seq_length = len(seq)
    columns = []

    for i in range(seq_length):
        columns.extend([
            f"seq_{i+1}_A",
            f"seq_{i+1}_C",
            f"seq_{i+1}_G",
            f"seq_{i+1}_T",
        ])

    columns.append("label")

    df = pd.DataFrame(data, columns=columns)
    return df


# 示例
if __name__ == "__main__":
    df = preprocess_promoter_gene_onehot("promoters.data")
    print(df.head())
    print(df.shape)
    df.to_csv('test.csv', index=False)
    clos = df.columns
    with open('list.txt', 'w') as file:
        for j in clos:
            file.write(str(j) + '\n')