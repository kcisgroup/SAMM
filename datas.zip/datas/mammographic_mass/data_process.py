import pandas as pd
from sklearn.preprocessing import MinMaxScaler

def preprocess_mammographic_mass(file_path):
    col_names = ["BI-RADS", "Age", "Shape", "Margin", "Density", "Severity"]

    df = pd.read_csv(file_path, header=None, names=col_names, na_values="?")
    df = df.dropna(axis=0).reset_index(drop=True)
    df = df.drop(columns=["BI-RADS"])
    df = df.rename(columns={"Severity": "label"})

    label = df["label"].reset_index(drop=True)
    features = df.drop(columns=["label"]).reset_index(drop=True)
    categorical_cols = ["Shape", "Margin"]
    df_onehot = pd.get_dummies(features[categorical_cols].astype(str)).astype(int).reset_index(drop=True)

    numeric_cols = ["Age", "Density"]
    scaler = MinMaxScaler()
    df_norm = pd.DataFrame(
        scaler.fit_transform(features[numeric_cols]),
        columns=numeric_cols
    ).reset_index(drop=True)

    final_df = pd.concat([df_norm, df_onehot], axis=1).reset_index(drop=True)
    final_df["label"] = label.values

    return final_df

# 示例使用
if __name__ == "__main__":
    df_processed = preprocess_mammographic_mass("mammographic_masses.data")
    print(df_processed.head())
    print("\nShape:", df_processed.shape)

    df_processed.to_csv('test.csv', index=False)
    clos = df_processed.columns
    with open('list.txt', 'w') as file:
        for j in clos:
            file.write(str(j) + '\n')
