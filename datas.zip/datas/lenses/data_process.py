import pandas as pd

data_path = "lenses.data"

df_raw = pd.read_csv(data_path, sep=r"\s+", header=None, engine="python")
print("df_raw:", df_raw.shape)

if df_raw.shape[1] == 6:
    df_raw.columns = ['index', 'age', 'spectacle_pres', 'astigmatism', 'tear_rate', 'label']
    df = df_raw.drop(columns=['index']).copy()
elif df_raw.shape[1] == 5:
    df_raw.columns = ['age', 'spectacle_pres', 'astigmatism', 'tear_rate', 'label']
    df = df_raw.copy()
else:
    raise ValueError(f"columns：{df_raw.shape[1]}.")

print("processed DataFrame shape:", df.shape)
print("display  5 lines ：\n", df.head(), "\n")


feature_cols = df.columns[:-1].tolist()
label_col = df.columns[-1]
print("features columns:", feature_cols)
print("label columns:", label_col, "\n")

if len(feature_cols) == 0:
    raise ValueError("data error")

df_features = pd.get_dummies(df[feature_cols].astype(str))
print("one-hot shape:", df_features.shape)
print("one-hot display", list(df_features.columns)[:20], "\n")
df_features = df_features.astype(int)

df_processed = pd.concat([df_features.reset_index(drop=True), df[label_col].reset_index(drop=True)], axis=1)

print("final DataFrame shape:", df_processed.shape)
print("data：\n", df_processed.head(), "\n")


df_processed.to_csv('test.csv', index=False)
clos = df_processed.columns
with open('list.txt', 'w') as file:
    for j in clos:
        file.write(str(j)+'\n')
