import pandas as pd


def preprocess_primary_tumor(file_path):
    col_names = [
        "erythema", "scaling", "definite-borders", "itching",
        "koebner phenomenon", "polygonal papules", "follicular papules",
        "oral-mucosal involvement", "knee elbow involvement", "scalp involvement",
        "family history", "melanin incontinence", "eosinophils in the infiltrate",
        "pnl infiltrate", "fibrosis of the papillary dermis", "exocytosis", "acanthosis",
        "hyperkeratosis", "parakeratosis", "clubbing of the rete ridges", "elongation of the rete ridges",
        "thinning of the suprapapillary epidermis", "spongiform pustule", "munro microabcess", "focal hypergranulosis",
        "disappearance of the granular layer", "vacuolisation and damage of the basal layer", "spongiosis",
        "saw-tooth appearance of retes", "follicular horn plug", "perifollicular parakeratosis",
        "inflammatory monoluclear infiltrate", "band-like infiltrate", "age", "class"
    ]

    df = pd.read_csv(file_path, header=None, names=col_names, na_values='?')
    print("df_raw shape:", df.shape)

    df = df.dropna(axis=1)

    print("droped shape:", df.shape)

    df_raw = df.rename(columns={"class": "label"})

    df_raw = df_raw.apply(pd.to_numeric)

    label_col = df_raw["label"]
    feature_df = df_raw.drop(columns=["label"])

    df_features = pd.get_dummies(feature_df.astype(str))

    df_features = df_features.astype(int)

    df_processed = pd.concat([df_features, label_col], axis=1)

    print("processed_data:", df_processed.shape)
    print(df_processed.head())

    df_processed.to_csv('test.csv', index=False)
    clos = df_processed.columns
    with open('list.txt', 'w') as file:
        for j in clos:
            file.write(str(j) + '\n')


if __name__ == "__main__":
    preprocess_primary_tumor("dermatology.data")

