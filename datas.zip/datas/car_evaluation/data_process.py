import pandas as pd

def preprocess_car_evaluation_numeric(file_path, verbose=False):
    col_names = ["buying", "maint", "doors", "persons", "lug_boot", "safety", "class"]

    df = pd.read_csv(file_path, names=col_names, header=None)

    if verbose:
        print("Raw df:", df.shape)

    df = df.rename(columns={"class": "label"})

    feature_cols = ["buying", "maint", "doors", "persons", "lug_boot", "safety"]

    feature_maps = {}
    for col in feature_cols:
        unique_vals = sorted(df[col].unique())
        mapping = {val: idx for idx, val in enumerate(unique_vals)}
        feature_maps[col] = mapping
        df[col] = df[col].map(mapping)
        if verbose:
            print(f"Mapping for {col}: {mapping}")

    unique_labels = sorted(df["label"].unique())
    label_map = {val: idx for idx, val in enumerate(unique_labels)}
    df["label"] = df["label"].map(label_map)

    if verbose:
        print("Label mapping:", label_map)

    label = df["label"]
    df = df.drop(columns=["label"])
    df["label"] = label.values

    if verbose:
        print("Final df:", df.shape)

    return df


if __name__ == "__main__":
    df_processed = preprocess_car_evaluation_numeric("car.data", verbose=True)
    print(df_processed.head())
    print("\nShape:", df_processed.shape)

    df_processed.to_csv('test.csv', index=False)
    clos = df_processed.columns
    with open('list.txt', 'w') as file:
        for j in clos:
            file.write(str(j) + '\n')
