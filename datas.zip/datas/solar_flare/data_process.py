import pandas as pd

data_path = "flare.data1"

df_raw = pd.read_csv(data_path, sep=r"\s+", header=None, engine="python")

columns = [
        "zurich_class",            # 1 (A,B,C,D,E,F,H)
        "largest_spot_size",       # 2 (X,R,S,A,H,K)
        "spot_distribution",       # 3 (X,O,I,C)
        "activity",                # 4 (1,2)
        "evolution",               # 5 (1,2,3)
        "flare_activity_24h",      # 6 (1,2,3)
        "historically_complex",    # 7 (1,2)
        "became_complex",          # 8 (1,2)
        "area",                    # 9 (1,2)
        "largest_spot_area",       # 10 (1,2)
        "C_flares",                # 11
        "M_flares",                # 12
        "X_flares"                 # 13
    ]

df_raw.columns = columns

print("raw data shape：", df_raw.shape)

df = df_raw.drop(columns=["X_flares", "M_flares"])

df = df.rename(columns={"C_flares": "label"})

label = df["label"]
features = df.drop(columns=["label"])

df_features = pd.get_dummies(features.astype(str))

df_features = df_features.astype(int)

df_processed = pd.concat([df_features.reset_index(drop=True), label.reset_index(drop=True)], axis=1)

print("processed data shape：", df_processed.shape)
print(df_processed.head())

df_processed.to_csv('test.csv', index=False)
clos = df_processed.columns
with open('list.txt', 'w') as file:
    for j in clos:
        file.write(str(j)+'\n')



