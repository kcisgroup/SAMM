import pandas as pd
from sklearn.preprocessing import MinMaxScaler


data_path = "processed.cleveland.data"

columns = [
    "age", "sex", "cp", "trestbps", "chol", "fbs",
    "restecg", "thalach", "exang", "oldpeak",
    "slope", "ca", "thal", "num"
]

df_raw = pd.read_csv(data_path, header=None, names=columns)

print("raw data shape:", df_raw.shape)

df = df_raw.replace("?", pd.NA)
df = df.dropna()

print("deleted data shape:", df.shape)

df = df.apply(pd.to_numeric)
df = df.rename(columns={"num": "label"})

categorical_cols = ["sex", "cp", "fbs", "restecg", "exang", "slope", "ca", "thal"]

all_cols = df.columns.tolist()
numeric_cols = [c for c in all_cols if c not in categorical_cols + ["label"]]

print("number features:", numeric_cols)
print("categorical features:", categorical_cols)

scaler = MinMaxScaler()
df_numeric = pd.DataFrame(scaler.fit_transform(df[numeric_cols]),
                          columns=numeric_cols)

df_categorical = pd.get_dummies(df[categorical_cols].astype(str))
df_categorical = df_categorical.astype(int)

df_processed = pd.concat(
    [df_numeric.reset_index(drop=True),
     df_categorical.reset_index(drop=True),
     df["label"].reset_index(drop=True)],
    axis=1
)

print("final processed data shape:", df_processed.shape)
print(df_processed.head())

df_processed.to_csv('test.csv', index=False)
clos = df_processed.columns
with open('list.txt', 'w') as file:
    for j in clos:
        file.write(str(j)+'\n')
