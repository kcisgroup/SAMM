import pandas as pd

def preprocess_congressional_voting(file_path):
    col_names = [
        "class",
        "handicapped-infants",
        "water-project-cost-sharing",
        "adoption-of-the-budget-resolution",
        "physician-fee-freeze",
        "el-salvador-aid",
        "religious-groups-in-schools",
        "anti-satellite-test-ban",
        "aid-to-nicaraguan-contras",
        "mx-missile",
        "immigration",
        "synfuels-corporation-cutback",
        "education-spending",
        "superfund-right-to-sue",
        "crime",
        "duty-free-exports",
        "export-administration-act-south-africa"
    ]

    df = pd.read_csv(file_path, header=None, names=col_names, na_values="?")

    df = df.dropna(axis=0)

    df = df.rename(columns={"class": "label"})

    label_map = {v: i for i, v in enumerate(df["label"].unique())}
    df["label"] = df["label"].map(label_map)

    label = df["label"]
    features = df.drop(columns=["label"])


    features_encoded = pd.get_dummies(features.astype(str)).astype(int)

    features_encoded["label"] = label.values

    return features_encoded, label_map


if __name__ == "__main__":
    processed_df, label_map = preprocess_congressional_voting("house-votes-84.data")
    print(processed_df.head())
    print("\nLabel map:", label_map)
    print("Shape:", processed_df.shape)

    processed_df.to_csv('test.csv', index=False)
    clos = processed_df.columns
    with open('list.txt', 'w') as file:
        for j in clos:
            file.write(str(j) + '\n')
